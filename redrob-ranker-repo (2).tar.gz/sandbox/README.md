# Sandbox deployment

This is a single Streamlit file (`app.py`) with no extra dependencies beyond
`streamlit` + `pandas` on top of the repo's `requirements.txt`.

## HuggingFace Spaces (recommended, free tier)

1. Create a new Space → SDK: **Streamlit**.
2. Push this repo's contents to the Space repo (or just `app.py`,
   `ranker.py`, and `requirements.txt` + a `sandbox/requirements.txt` with
   `streamlit` and `pandas` added).
3. Space entrypoint: `sandbox/app.py` (set this as the "App file" in the
   Space settings, or move `app.py` to the repo root for the Space).
4. Upload `sample_candidates.json` from the hackathon bundle when the app
   loads to verify it runs end-to-end.

## Streamlit Community Cloud

1. Push this repo to GitHub.
2. New app → point at `sandbox/app.py`.
3. Add `streamlit` and `pandas` to `requirements.txt` (or a separate
   `sandbox/requirements.txt` referenced in the app settings) alongside
   `scikit-learn`.

## Local run

```bash
pip install -r requirements.txt streamlit pandas
streamlit run sandbox/app.py
```
