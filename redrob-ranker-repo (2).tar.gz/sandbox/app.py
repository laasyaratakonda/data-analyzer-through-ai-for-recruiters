"""
sandbox/app.py — small-sample Streamlit demo for Stage-1 sandbox verification.

Deploy this single file to HuggingFace Spaces or Streamlit Cloud (Streamlit
SDK). It lets a reviewer upload a small candidate sample (<=100 candidates,
e.g. sample_candidates.json from the bundle) and see the ranker run
end-to-end, fully offline, in seconds.

Run locally with:
    streamlit run sandbox/app.py
"""

import json
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from ranker import score_candidates  # noqa: E402

st.set_page_config(page_title="Redrob Ranker — Sandbox", layout="wide")
st.title("Redrob Candidate Ranker — Sandbox")
st.caption(
    "Upload a small candidate sample (JSON array or JSONL, <=100 candidates) "
    "to see the offline, CPU-only hybrid ranker run end-to-end. This is the "
    "same ranker.py used by rank.py for the full 100K pool."
)

uploaded = st.file_uploader("Candidate sample (.json or .jsonl)", type=["json", "jsonl"])

if uploaded is not None:
    raw = uploaded.read().decode("utf-8")
    if uploaded.name.endswith(".jsonl"):
        candidates = [json.loads(line) for line in raw.splitlines() if line.strip()]
    else:
        candidates = json.loads(raw)

    st.write(f"Loaded **{len(candidates)}** candidates.")

    with st.spinner("Scoring (offline, CPU-only, no network calls)..."):
        scored = score_candidates(candidates)
        scored.sort(key=lambda r: (r.honeypot, -r.score, r.candidate_id))

    df = pd.DataFrame(
        [
            {
                "rank": i + 1,
                "candidate_id": r.candidate_id,
                "score": round(r.score, 4),
                "honeypot_flag": r.honeypot,
                "reasoning": r.reasoning,
            }
            for i, r in enumerate(scored)
        ]
    )
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.download_button(
        "Download ranked CSV",
        df.to_csv(index=False).encode("utf-8"),
        file_name="sandbox_ranking.csv",
        mime="text/csv",
    )
else:
    st.info("Try it with the bundle's `sample_candidates.json` (50 candidates).")
