"""
ranker.py — Hybrid candidate-ranking engine for the Redrob Intelligent
Candidate Discovery & Ranking Challenge.

Design goals (per submission_spec.docx):
  * CPU-only, no network, no GPU, runs the full 100K pool in well under
    5 minutes on a 16 GB machine.
  * No per-candidate LLM calls. Semantic understanding comes from a local
    TF-IDF model (cheap, deterministic, reproducible) combined with explicit
    rule-based feature scoring built directly from the JD's stated
    requirements/disqualifiers and the candidate schema / behavioral
    signals.
  * Reasoning strings are generated only from fields actually present on
    the candidate record (no hallucinated skills).
  * Honeypots (subtly-impossible profiles) are detected with explicit
    consistency checks and pushed to the bottom of the ranking.

This module is imported by rank.py (the CLI entrypoint).
"""

from __future__ import annotations

import datetime as dt
import json
import math
import re
from dataclasses import dataclass, field
from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

TODAY = dt.date(2026, 1, 1)  # fixed reference date -> fully reproducible runs

# ----------------------------------------------------------------------
# JD-derived vocab (Section: "The skills inventory", job_description.txt)
# ----------------------------------------------------------------------

MUST_HAVE_GROUPS: dict[str, list[str]] = {
    "embeddings_retrieval": [
        "sentence-transformers", "sentence transformers", "embeddings",
        "embedding", "bge", "e5", "openai embeddings", "dense retrieval",
        "semantic search", "retrieval",
    ],
    "vector_db_hybrid_search": [
        "pinecone", "weaviate", "qdrant", "milvus", "opensearch",
        "elasticsearch", "faiss", "hybrid search", "bm25", "vector database",
        "vector db",
    ],
    "python_quality": ["python"],
    "eval_frameworks": [
        "ndcg", "mrr", "map", "a/b test", "ab test", "offline evaluation",
        "online evaluation", "evaluation framework", "precision@", "recall@",
    ],
}

NICE_TO_HAVE = [
    "lora", "qlora", "peft", "fine-tuning", "fine tuning",
    "learning to rank", "learning-to-rank", "xgboost", "ltr",
    "recruiting", "recruitment", "hr-tech", "hr tech", "marketplace",
    "distributed systems", "large-scale inference", "inference optimization",
    "open source", "open-source",
]

NLP_IR_TERMS = [
    "nlp", "natural language", "retrieval", "search", "ranking", "llm",
    "language model", "information retrieval", "text", "embedding",
]
CV_SPEECH_ROBOTICS_TERMS = [
    "computer vision", "image classification", "object detection",
    "speech recognition", "tts", "robotics", "autonomous", "lidar",
    "slam", "asr",
]

PRODUCTION_EVIDENCE_TERMS = [
    "production", "deployed", "real users", "scale", "users", "shipped",
    "live traffic", "rolled out", "in production",
]
RESEARCH_ONLY_TERMS = ["research scientist", "research engineer", "academic", "phd researcher", "research lab"]

CONSULTING_FIRMS = [
    "tcs", "tata consultancy", "infosys", "wipro", "accenture", "cognizant",
    "capgemini", "hcl", "tech mahindra", "mindtree", "mphasis", "l&t infotech",
    "ltimindtree",
]

LANGCHAIN_OPENAI_ONLY = ["langchain", "openai api", "gpt wrapper", "chatgpt api"]

TITLE_LADDER = ["associate", "engineer", "senior", "staff", "principal", "lead", "head", "director", "vp"]

TIER1_CITIES = [
    "pune", "noida", "bangalore", "bengaluru", "hyderabad", "mumbai",
    "delhi", "gurgaon", "gurugram", "chennai", "kolkata", "delhi ncr",
]

JD_FREE_TEXT = """
Senior AI Engineer, founding team, Series A AI-native talent intelligence
platform. Owns ranking, retrieval and matching systems end to end.
Needs production experience with embeddings-based retrieval (sentence
transformers, OpenAI embeddings, BGE, E5), production experience with
vector databases or hybrid search infrastructure (Pinecone, Weaviate,
Qdrant, Milvus, OpenSearch, Elasticsearch, FAISS), strong Python, and
hands-on design of evaluation frameworks for ranking (NDCG, MRR, MAP,
offline-to-online correlation, A/B testing). Nice to have: LLM fine-tuning
(LoRA/QLoRA/PEFT), learning-to-rank, HR-tech/recruiting/marketplace
background, distributed systems, open-source contributions. Wants someone
who ships, not just researches; 5-9 years broadly, located in or willing
to relocate to Pune or Noida, India, quarterly travel for offsites, short
notice period preferred.
"""


def _text_has_any(text: str, terms: list[str]) -> bool:
    return any(t in text for t in terms)


def _count_any(text: str, terms: list[str]) -> int:
    return sum(1 for t in terms if t in text)


def _years_since(date_str: str | None) -> float | None:
    if not date_str:
        return None
    try:
        d = dt.date.fromisoformat(date_str[:10])
    except ValueError:
        return None
    return (TODAY - d).days / 365.25


@dataclass
class ScoredCandidate:
    candidate_id: str
    score: float
    reasoning: str
    honeypot: bool = False
    tiebreak: tuple = field(default_factory=tuple)


def candidate_corpus_text(c: dict[str, Any]) -> str:
    """Flatten the fields relevant to semantic matching into one string."""
    p = c.get("profile", {})
    parts = [
        p.get("headline", ""), p.get("summary", ""),
        p.get("current_title", ""), p.get("current_industry", ""),
    ]
    for job in c.get("career_history", []) or []:
        parts.append(job.get("title", ""))
        parts.append(job.get("industry", ""))
        parts.append(job.get("description", ""))
    for s in c.get("skills", []) or []:
        parts.append(s.get("name", ""))
    return " \n".join(p_ for p_ in parts if p_).lower()


def detect_honeypot(c: dict[str, Any]) -> bool:
    """Cheap, explicit consistency checks for subtly-impossible profiles."""
    profile = c.get("profile", {})
    yoe = profile.get("years_of_experience", 0) or 0

    # 1. Sum of career_history duration wildly exceeds stated years of experience.
    total_months = sum((j.get("duration_months") or 0) for j in c.get("career_history", []) or [])
    if total_months > (yoe * 12 + 18):  # >1.5y slack
        return True

    # 2. "expert" proficiency claimed with ~0 months of hands-on duration.
    for s in c.get("skills", []) or []:
        if s.get("proficiency") == "expert" and (s.get("duration_months") or 0) <= 2:
            return True

    # 3. Overlapping full-time roles that both claim long, current tenure
    #    (more than two simultaneous "is_current" jobs).
    current_jobs = [j for j in c.get("career_history", []) or [] if j.get("is_current")]
    if len(current_jobs) > 1:
        return True

    # 4. Education ends after the candidate claims to have started working
    #    full-time career years that predate it by an impossible margin.
    edu = c.get("education", []) or []
    history = c.get("career_history", []) or []
    if edu and history:
        try:
            latest_edu_end = max(e.get("end_year", 0) for e in edu)
            earliest_job_start = min(int(j["start_date"][:4]) for j in history if j.get("start_date"))
            if earliest_job_start < latest_edu_end - 1:  # working a full job >1y before graduating
                return True
        except (ValueError, KeyError, TypeError):
            pass

    # 5. years_of_experience inconsistent with age implied by education start.
    if edu:
        try:
            earliest_edu_start = min(e.get("start_year", 9999) for e in edu)
            implied_career_start = earliest_edu_start + 17  # ~earliest plausible age 17 entering UG
            if (TODAY.year - implied_career_start) < yoe - 2:
                return True
        except (ValueError, TypeError):
            pass

    return False


def _company_quality(c: dict[str, Any]) -> tuple[float, bool, bool]:
    """Returns (score_delta, is_consulting_only, has_product_evidence)."""
    history = c.get("career_history", []) or []
    if not history:
        return 0.0, False, False
    companies = [(j.get("company") or "").lower() for j in history]
    is_consulting_only = all(any(f in comp for f in CONSULTING_FIRMS) for comp in companies)
    text = candidate_corpus_text(c)
    has_product_evidence = _text_has_any(text, PRODUCTION_EVIDENCE_TERMS)
    if is_consulting_only and not has_product_evidence:
        return -0.30, True, False
    if is_consulting_only and has_product_evidence:
        return -0.05, True, True
    return 0.05, False, has_product_evidence


def _title_chasing(c: dict[str, Any]) -> bool:
    history = sorted(
        [j for j in c.get("career_history", []) or [] if j.get("start_date")],
        key=lambda j: j["start_date"],
    )
    if len(history) < 3:
        return False
    short_stints = sum(1 for j in history if (j.get("duration_months") or 999) <= 18)
    escalating = 0
    last_level = -1
    for j in history:
        title = (j.get("title") or "").lower()
        level = max((TITLE_LADDER.index(t) for t in TITLE_LADDER if t in title), default=-1)
        if level > last_level:
            escalating += 1
            last_level = level
    return short_stints >= max(2, len(history) - 1) and escalating >= 3


def _experience_fit(yoe: float) -> float:
    # Gaussian-ish band centered on 5-9 years, gentle falloff outside it.
    if 5 <= yoe <= 9:
        return 1.0
    dist = (5 - yoe) if yoe < 5 else (yoe - 9)
    return max(0.0, 1.0 - dist / 6.0)


def _location_fit(c: dict[str, Any]) -> float:
    profile = c.get("profile", {})
    sig = c.get("redrob_signals", {})
    loc = (profile.get("location") or "").lower()
    country = (profile.get("country") or "").lower()
    if any(city in loc for city in ("pune", "noida")):
        return 1.0
    if any(city in loc for city in TIER1_CITIES):
        return 0.8
    if country == "india":
        return 0.55 if sig.get("willing_to_relocate") else 0.35
    return 0.25 if sig.get("willing_to_relocate") else 0.05


def _behavioral_multiplier(sig: dict[str, Any]) -> float:
    if not sig:
        return 0.85
    mult = 1.0
    last_active = _years_since(sig.get("last_active_date"))
    if last_active is not None:
        days = last_active * 365.25
        if days <= 14:
            mult += 0.08
        elif days <= 30:
            mult += 0.03
        elif days <= 90:
            mult -= 0.05
        elif days <= 180:
            mult -= 0.15
        else:
            mult -= 0.30

    rr = sig.get("recruiter_response_rate")
    if rr is not None:
        mult += (rr - 0.5) * 0.20  # +/-0.10 swing

    if sig.get("open_to_work_flag"):
        mult += 0.05

    icr = sig.get("interview_completion_rate")
    if icr is not None:
        mult += (icr - 0.5) * 0.10

    pcs = sig.get("profile_completeness_score")
    if pcs is not None:
        mult += (pcs / 100.0 - 0.7) * 0.08

    oar = sig.get("offer_acceptance_rate")
    if oar is not None and oar >= 0:
        mult += (oar - 0.5) * 0.06

    notice = sig.get("notice_period_days")
    if notice is not None:
        if notice <= 30:
            mult += 0.05
        elif notice <= 60:
            mult += 0.0
        elif notice <= 90:
            mult -= 0.05
        else:
            mult -= 0.10

    if sig.get("verified_email"):
        mult += 0.01
    if sig.get("verified_phone"):
        mult += 0.01

    return max(0.4, min(1.25, mult))


def build_reasoning(c: dict[str, Any], hits: list[str], nice_hits: list[str],
                     flags: list[str], honeypot: bool) -> str:
    p = c.get("profile", {})
    sig = c.get("redrob_signals", {})
    yoe = p.get("years_of_experience")
    title = p.get("current_title", "")
    company = p.get("current_company", "")
    loc = p.get("location", "")
    rr = sig.get("recruiter_response_rate")
    notice = sig.get("notice_period_days")
    last_active = _years_since(sig.get("last_active_date"))
    days_active = int(last_active * 365.25) if last_active is not None else None

    if honeypot:
        return (f"Flagged as a honeypot: profile data is internally inconsistent "
                f"(e.g. claimed tenure/skill duration doesn't add up) — excluded from genuine ranking.")

    bits = [f"{yoe}y exp, {title} at {company} ({loc})."]
    if hits:
        bits.append(f"Core JD skills evidenced: {', '.join(hits[:3])}.")
    else:
        bits.append("Limited direct evidence of the JD's must-have retrieval/eval stack.")
    if nice_hits:
        bits.append(f"Also shows {', '.join(nice_hits[:2])}.")
    if flags:
        bits.append("Concerns: " + "; ".join(flags) + ".")
    if rr is not None:
        bits.append(f"Recruiter response rate {rr:.0%}" + (f", active {days_active}d ago" if days_active is not None else "") + (f", notice {notice}d." if notice is not None else "."))
    return " ".join(bits)[:480]


def score_candidates(candidates: list[dict[str, Any]]) -> list[ScoredCandidate]:
    texts = [candidate_corpus_text(c) for c in candidates]
    vec = TfidfVectorizer(max_features=30000, ngram_range=(1, 2), min_df=2, stop_words="english")
    matrix = vec.fit_transform(texts + [JD_FREE_TEXT.lower()])
    jd_vec = matrix[-1]
    cand_matrix = matrix[:-1]
    sims = linear_kernel(cand_matrix, jd_vec).ravel()  # cosine sim since tfidf is l2-normed
    sim_min, sim_max = float(sims.min()), float(sims.max())
    sim_range = (sim_max - sim_min) or 1.0

    results: list[ScoredCandidate] = []
    for i, c in enumerate(candidates):
        cid = c.get("candidate_id", f"UNK_{i}")
        text = texts[i]
        profile = c.get("profile", {})
        sig = c.get("redrob_signals", {})
        yoe = profile.get("years_of_experience") or 0.0

        honeypot = detect_honeypot(c)

        semantic = (sims[i] - sim_min) / sim_range  # normalized 0-1

        hits, missing = [], []
        for group, terms in MUST_HAVE_GROUPS.items():
            if _text_has_any(text, terms):
                hits.append(group.replace("_", " "))
            else:
                missing.append(group)
        must_have_coverage = len(hits) / len(MUST_HAVE_GROUPS)

        nice_hits = [t for t in NICE_TO_HAVE if t in text]
        nice_bonus = min(0.05, 0.01 * len(set(nice_hits)))

        exp_fit = _experience_fit(yoe)
        loc_fit = _location_fit(c)
        comp_delta, is_consulting_only, has_product_evidence = _company_quality(c)

        flags = []
        penalty = 0.0
        if _text_has_any(text, RESEARCH_ONLY_TERMS) and not has_product_evidence:
            penalty -= 0.45
            flags.append("research-only background, no production deployment evidence")
        if is_consulting_only and not has_product_evidence:
            flags.append("consulting-only career history (TCS/Infosys/Wipro-type), no product-company evidence")
        if _text_has_any(text, LANGCHAIN_OPENAI_ONLY) and not _text_has_any(text, ["sentence-transformers", "faiss", "elasticsearch", "vector database", "pre-llm", "bm25"]):
            recent_only = True
            if recent_only:
                penalty -= 0.20
                flags.append("AI experience looks LangChain/OpenAI-wrapper only, no pre-LLM-era IR/ranking evidence")
        if _text_has_any(text, CV_SPEECH_ROBOTICS_TERMS) and not _text_has_any(text, NLP_IR_TERMS):
            penalty -= 0.25
            flags.append("CV/speech/robotics background without NLP or retrieval exposure")
        if _title_chasing(c):
            penalty -= 0.15
            flags.append("rapid title-escalation across short stints (possible title-chaser)")

        base = (
            0.30 * semantic
            + 0.25 * must_have_coverage
            + 0.10 * exp_fit
            + 0.07 * loc_fit
            + nice_bonus
            + comp_delta
            + penalty
        )
        base = max(0.0, min(1.0, base))

        mult = _behavioral_multiplier(sig)
        score = base * mult
        score = max(0.0, min(1.0, score))

        if honeypot:
            score = min(score, 0.01)

        reasoning = build_reasoning(c, hits, nice_hits, flags, honeypot)
        results.append(ScoredCandidate(
            candidate_id=cid,
            score=score,
            reasoning=reasoning,
            honeypot=honeypot,
            tiebreak=(round(must_have_coverage, 4), round(semantic, 4)),
        ))

    return results
