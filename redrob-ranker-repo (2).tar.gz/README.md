# Redrob Hackathon — Intelligent Candidate Discovery & Ranking

A hybrid (no-LLM-at-inference-time) candidate ranker for the *Senior AI
Engineer, Founding Team* JD. Reads `candidates.jsonl` (100K profiles),
scores every candidate, and writes the top-100 as a submission CSV matching
`submission_spec.md`.

## Why this design

The compute constraints (CPU-only, no network, no GPU, 5-minute budget,
reproduced in a sandboxed container at Stage 3) rule out per-candidate LLM
calls on 100K rows. So "understanding" the JD vs. keyword-matching it is
done two ways instead:

1. **Semantic layer** — a local TF-IDF + cosine-similarity match between
   each candidate's flattened profile/career-history/skills text and the
   JD's requirements, so candidates are matched on *meaning* even when they
   don't use the JD's exact vocabulary (e.g. a candidate who built a
   recommendation system but never wrote "RAG").
2. **Rule layer derived directly from the JD's own stated logic** —
   `job_description.txt` is explicit about must-haves, nice-to-haves, and
   *disqualifiers* ("we explicitly do NOT want..."). `ranker.py` encodes
   those as features: must-have skill-cluster coverage, a penalty for
   research-only backgrounds with no production deployment evidence, a
   penalty for consulting-only career history (TCS/Infosys/Wipro/etc.) with
   no product-company evidence, a penalty for CV/speech/robotics
   backgrounds without NLP/IR exposure, a penalty for LangChain/OpenAI-API-only
   "AI experience" with no pre-LLM-era IR evidence, and a penalty for
   rapid title-escalation across short stints (title-chasing).

On top of that, a **behavioral multiplier** built from `redrob_signals`
(recency of activity, recruiter response rate, interview completion rate,
profile completeness, notice period, verification flags) scales the score
up or down — a perfect-on-paper candidate who's gone quiet for 6 months is
down-weighted, per the JD's own instruction.

**Honeypots** are caught with explicit internal-consistency checks (not
keyword rules), since the brief says they're "subtly impossible" rather
than badly written:
- total career-history duration far exceeding stated years of experience
- "expert" skill proficiency with ~0 months of hands-on duration
- more than one simultaneous "current" job
- education ending after a full-time job already started
- years of experience inconsistent with the earliest plausible graduation date

Flagged honeypots are forced to (effectively) the bottom of the ranking
rather than hard-excluded, so the pipeline stays auditable and a reviewer
can see exactly why each one was caught (see the `reasoning` column).

**Reasoning** is generated only from fields actually on the candidate
record (years of experience, current title/company/location, which
must-have skill clusters were evidenced, behavioral numbers) — never
invented — to avoid the hallucination failure mode the spec explicitly
penalizes at Stage 4.

## Run it

```bash
pip install -r requirements.txt
python rank.py --candidates ./candidates.jsonl --out ./submission.csv
python validate_submission.py submission.csv   # sanity check against the spec
```

On a single CPU core this scores the full 100,000-candidate pool in
~70-90 seconds, well inside the 5-minute budget, and uses well under 1 GB
of RAM. No network calls and no GPU are used at any point.

`candidates.jsonl` (or `.jsonl.gz`) and the original hackathon docs are not
checked into this repo (the pool is ~500 MB) — drop the bundle's
`candidates.jsonl` next to `rank.py` before running, or pass `--candidates`
pointing at wherever you unpacked it.

## Repo layout

```
ranker.py            # scoring engine (semantic + rule + behavioral layers, honeypot detection)
rank.py               # CLI entrypoint -> writes the submission CSV
requirements.txt
sandbox/app.py         # Streamlit sandbox app (small-sample, hosted demo) — see sandbox/README.md
data/                  # copies of schema/spec reference files from the hackathon bundle
submission_metadata.yaml
validate_submission.py # spec validator, copied from the bundle
```

## Tuning / extending

All scoring weights live as named constants near the top of
`score_candidates()` in `ranker.py`. The must-have/nice-to-have vocab and
disqualifier term lists are also there as plain Python lists, so they're
easy to extend without touching the scoring logic. A natural next step if
more compute budget were available offline (not at inference time) would
be to replace TF-IDF with a precomputed local sentence-embedding index
(e.g. a small `sentence-transformers` model run once to embed all 100K
candidates ahead of time, cached to disk) — the ranking step would stay
just as fast since it would only need a single forward pass on the JD plus
a matrix multiply.

## AI tools

See `submission_metadata.yaml` → `ai_tools_used` / `ai_usage_summary` —
please fill in honestly with your own workflow before submitting.
