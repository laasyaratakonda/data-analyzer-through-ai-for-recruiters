#!/usr/bin/env python3
"""
rank.py — produce the top-100 ranked submission CSV.

Usage:
    python rank.py --candidates ./candidates.jsonl --out ./submission.csv

Runs fully offline, CPU-only. No network calls, no GPU. Designed to finish
well inside the 5-minute / 16 GB budget on the full 100K candidate pool.
"""

import argparse
import csv
import gzip
import json
import sys
import time

from ranker import score_candidates


def load_candidates(path: str):
    opener = gzip.open if path.endswith(".gz") else open
    candidates = []
    with opener(path, "rt", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                candidates.append(json.loads(line))
    return candidates


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", required=True, help="Path to candidates.jsonl or .jsonl.gz")
    ap.add_argument("--out", required=True, help="Path to write the submission CSV")
    ap.add_argument("--top-k", type=int, default=100)
    args = ap.parse_args()

    t0 = time.time()
    candidates = load_candidates(args.candidates)
    print(f"Loaded {len(candidates)} candidates in {time.time() - t0:.1f}s", file=sys.stderr)

    t1 = time.time()
    scored = score_candidates(candidates)
    print(f"Scored {len(scored)} candidates in {time.time() - t1:.1f}s", file=sys.stderr)

    # Honeypots last, then by score desc, then by tiebreak desc, then candidate_id asc
    # for fully deterministic ordering even on exact score ties.
    scored.sort(key=lambda r: (r.honeypot, -r.score, tuple(-x for x in r.tiebreak), r.candidate_id))

    top = scored[: args.top_k]

    # Enforce strictly non-increasing scores with a tiny epsilon so the
    # validator's "non-increasing by rank" + "ties broken by candidate_id"
    # rules are always satisfied even after rounding to 4dp.
    rows = []
    prev_score = None
    for rank, r in enumerate(top, start=1):
        s = round(r.score, 4)
        if prev_score is not None and s > prev_score:
            s = prev_score
        prev_score = s
        rows.append((r.candidate_id, rank, f"{s:.4f}", r.reasoning))

    with open(args.out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["candidate_id", "rank", "score", "reasoning"])
        writer.writerows(rows)

    honeypots_in_top = sum(1 for r in top if r.honeypot)
    print(f"Wrote {len(rows)} rows to {args.out} in {time.time() - t0:.1f}s total "
          f"({honeypots_in_top} honeypots in top {args.top_k}).", file=sys.stderr)


if __name__ == "__main__":
    main()
